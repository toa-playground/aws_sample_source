# -*- coding: utf-8 -*-
/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: MIT-0
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
import json
import os
import time
from threading import Timer

import gluoncv as gcv
import greengrasssdk
import mxnet as mx
import numpy as np
from gluoncv.utils import try_import_cv2

os.environ['MXNET_CUDNN_AUTOTUNE_DEFAULT'] = '0'

cv2 = try_import_cv2()

client = greengrasssdk.client('iot-data')

TOPIC = os.environ.get('TOPIC', 'predict/person')
ERROR_TOPIC = os.environ.get('ERROR_TOPIC', 'predict/error')

PREDICT_THRESHOLD = float(os.environ.get('PREDICT_THRESHOLD', '0.7'))

CAM_DEVICE = os.environ.get('CAM_DEVICE', '/dev/video0')
CAM_WIDTH = int(os.environ.get('CAM_WIDTH', '1280'))
CAM_HEIGHT = int(os.environ.get('CAM_HEIGHT', '720'))
PREDICT_INTERVAL = int(os.environ.get('PREDICT_INTERVAL', '60'))

GST_STR = ('v4l2src device={} ! video/x-raw, width=(int){}, height=(int){} ! videoconvert ! appsink').format(
    CAM_DEVICE, CAM_WIDTH, CAM_HEIGHT)

# 推論に使うコンテキストを設定
if os.environ.get('PREDICT_DEVICE', 'GPU').upper() == 'GPU':
    ctx = mx.gpu()
else:
    ctx = mx.cpu()

# ビデオキャプチャデバイスを作成
cap = cv2.VideoCapture(GST_STR, cv2.CAP_GSTREAMER)

# 事前学習済みモデルを読み込み、人物だけ検知できるようにclassをリセット
net = gcv.model_zoo.get_model(
    'ssd_512_mobilenet1.0_voc', pretrained=True, ctx=ctx)
net.reset_class(classes=['person'], reuse_weights=['person'])


def predict():
    # USBカメラから画像を読み込み
    ret, frame = cap.read()
    if not ret:
        # エラーをPublish
        client.publish(topic=ERROR_TOPIC, qos=0, payload=json.dumps(
            {'error': 'capture read error'}))
    else:
        # 推論に向けて画像を変換
        frame = mx.nd.array(cv2.cvtColor(
            frame, cv2.COLOR_BGR2RGB)).astype('uint8')
        rgb_nd, _ = gcv.data.transforms.presets.ssd.transform_test(
            frame, short=512, max_size=700)
        rgb_nd = rgb_nd.as_in_context(ctx)

        # 推論
        predict_start = time.time()
        _, scores, _ = net(rgb_nd)
        predict_sec = time.time() - predict_start

        # 推論結果をPublish
        persons = np.count_nonzero(
            scores.asnumpy() > PREDICT_THRESHOLD, axis=1)[0][0]
        result = {'persons': int(persons), 'timestamp': int(
            time.time()), 'predict_sec': predict_sec}
        client.publish(topic=TOPIC, qos=0, payload=json.dumps(result))

    # タイマーを作成して指定時間後に改めてpredict関数を呼び出す
    Timer(PREDICT_INTERVAL, predict).start()


def lambda_handler(event, context):
    return


predict()
